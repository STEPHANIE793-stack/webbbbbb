# Christmas Wishes

A Pen created on CodePen.io. Original URL: [https://codepen.io/trishasalas/pen/Zagrav](https://codepen.io/trishasalas/pen/Zagrav).

Uses CSS Grid for layout and Particle.js for the snow. 

Image credit to fireflamenco on VectorStock https://www.vectorstock.com/royalty-free-vectors/vectors-by_fireflamenco